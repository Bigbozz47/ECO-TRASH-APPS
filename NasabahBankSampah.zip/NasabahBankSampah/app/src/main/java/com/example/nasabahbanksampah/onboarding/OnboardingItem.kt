package com.example.nasabahbanksampah.onboarding

data class OnboardingItem(
    val imageRes: Int,
    val title: String,
    val description: String
)